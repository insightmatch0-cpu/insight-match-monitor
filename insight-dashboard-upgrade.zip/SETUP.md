# InsightMatch Dashboard — Setup Guide

Everything runs on your existing free setup (GitHub Actions + API-Football free tier + Claude Haiku). No servers, no new accounts.

## What's in this package

| File | What it does | Action |
|---|---|---|
| `index.html` | The dashboard page (Arabic, with EN toggle) | **New** — upload |
| `data.json` | Starter data file the page reads | **New** — upload |
| `predict.py` | Daily 24h predictions + self-learning accuracy log | **New** — upload |
| `dashboard_update.py` | Builds `data.json` + fetches free news feeds | **New** — upload |
| `monitor.py` | Your existing monitor + small additions for the dashboard | **Replace** existing |
| `.github/workflows/monitor.yml` | Your existing workflow + dashboard step | **Replace** existing |
| `.github/workflows/predict.yml` | New daily predictions schedule (06:15 AM KSA) | **New** — upload |
| `.github/workflows/scan.yml` | Your Live Scan workflow, moved to the CORRECT folder | **New** — upload |

## Step 0 — Rotate your keys first (important)

Your keys appeared in a screenshot, so treat them as compromised:
1. console.anthropic.com → API Keys → delete old, create new
2. dashboard.api-football.com → regenerate key
3. Repo → Settings → Secrets and variables → Actions → update `ANTHROPIC_API_KEY` and `API_FOOTBALL_KEY`

## Step 1 — Upload the files

Easiest on a computer:
1. Open your repo → **Add file → Upload files**
2. Drag ALL contents of this package (keep the folder structure)
3. Commit. GitHub will ask to overwrite `monitor.py` and `monitor.yml` — that's correct.

On a phone: open each file in this package, copy its content, then in GitHub use **Add file → Create new file**, type the full path as the filename (e.g. `.github/workflows/predict.yml`) and paste. For `monitor.py` and `monitor.yml`, open the existing file → pencil icon → select all → paste the new version.

## Step 2 — Delete the broken folder

Your Live Scan workflow was nested in the wrong place, so its button never worked.
Go to `.github/workflows/.github/` in your repo → "…" menu → **Delete directory** → commit.
(The corrected `scan.yml` from this package replaces it.)

## Step 3 — Turn on GitHub Pages

Repo → **Settings → Pages** → Source: **Deploy from a branch** → Branch: **main**, folder: **/ (root)** → Save.

Your dashboard will be live in ~2 minutes at:
**https://insightmatch0-cpu.github.io/insight-match-monitor/**
(Add it to your phone's home screen — it behaves like an app.)

## Step 4 — First run

Repo → **Actions → Daily Predictions → Run workflow**. Within ~2 minutes you'll get the Telegram digest and the dashboard fills up. After that it runs automatically every morning, and the live section updates every 20 minutes with your existing monitor.

## How the self-learning works

- Every prediction is saved with its confidence level.
- The next day, the system checks the real results and marks each prediction right/wrong.
- Every new prediction request sends Claude its own real track record ("when you said 70%+ you were actually right X% of the time") so it calibrates itself over time.
- The dashboard shows accuracy overall, last 30 days, and per confidence level.

## Budget (stays inside free tiers)

- API-Football: monitor ~72 calls/day + predictions max 5 calls/day = ~77 of your 100.
- Claude Haiku: predictions are batched (12 matches per call) → roughly 5 calls/day, a few cents per month.
- News: free RSS feeds (BBC, BBC Arabic, Sky Sports, The Guardian) — zero cost, editable in `dashboard_update.py` under `NEWS_FEEDS`.

## Knobs you can change (top of `predict.py`)

- `MAX_PREDICTIONS_24H = 60` — daily prediction cap (raise/lower for cost)
- `DIGEST_TOP_ONLY = True` — Telegram digest shows top leagues only; the rest live on the dashboard
- `SEND_TELEGRAM_DIGEST = True` — turn the morning digest on/off
